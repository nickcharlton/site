# Examples to "Drawing Primitives with Quartz"

This repository contains a bunch of examples for drawing simple graphics using Quartz, the graphics library that is part of iOS and Mac OS X. It accompanies a blog post I wrote entitled: [Drawing Primitives with Quartz](http://nickcharlton.net/drawing-primitives).

It looks like this:

<img src="http://nickcharlton.net/resources/drawing-primitives/final.png" width="386" height="716">

## License

Copyright Nick Charlton 2011. Licensed under the MIT licence.
