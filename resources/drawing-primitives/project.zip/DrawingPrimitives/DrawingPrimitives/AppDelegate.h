//
//  AppDelegate.h
//  DrawingPrimitives
//
//  Created by Nick Charlton on 26/11/2011.
//  Copyright (c) 2011 Nick Charlton. Licensed under the MIT license.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
