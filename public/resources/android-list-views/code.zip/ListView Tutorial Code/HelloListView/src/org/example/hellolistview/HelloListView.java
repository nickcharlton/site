package org.example.hellolistview;

import java.util.ArrayList;
import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class HelloListView extends ListActivity {
	private ArrayList<String> data;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // setup the data source
        this.data = new ArrayList<String>();
        
        // add some objects into the array list
        this.data.add("List Item 1");
        this.data.add("List Item 2");
        this.data.add("List Item 3");
        
        // use main.xml for the layout
        setContentView(R.layout.main);
        
        // setup the data adaptor
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.text, this.data);
        
        // specify the list adaptor
        setListAdapter(adapter);
    }
}